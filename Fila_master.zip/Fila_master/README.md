<p>"Synthesizing Filamentary Structured Images with GANs" makalesinden alıntıdır.</p><br>
Makale linki : https://arxiv.org/pdf/1706.02185.pdf<br>
Detaylı bilgi için:https://web.bii.a-star.edu.sg/archive/machine_learning/Projects/filaStructObjs/Synthesis/index.html adresini ziyaret etmelisiniz.
